import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { PenaltyService } from '../Service/penalty.service';
import { map} from 'rxjs/operators'
import { Country } from '../Model/Country';
import { Input } from '../Model/Input';
import { Output } from '../Model/Output';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
})
export class HomeComponent implements OnInit {
    myForm: FormGroup;
    countryList: Country[]
    input: Input
    constructor(private formBuilder: FormBuilder, private service: PenaltyService) { }
    ngOnInit(): void{
        this.myForm = this.formBuilder.group({
            startDate: [''],
            endDate: [''],
            country:['']
        })
        this.service.getList().pipe(map((data: Country[]) => {
            if (data != null && data != undefined) {
                this.countryList = data;
            }

        })).subscribe()
    }
    onSubmit() {
        this.input = {
            startDate: this.myForm.get('startDate').value,
            endDate: this.myForm.get('endDate').value,
            country: this.myForm.get('country').value
        }
        console.log(this.input)
        this.service.GetPenalty(this.input).pipe(map((data: Output) => {

            if (data != null && data != undefined) {
                console.log(data);
            }
        }))
    }
}
