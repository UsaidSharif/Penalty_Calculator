"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var testing_1 = require("@angular/core/testing");
var penalty_service_1 = require("./penalty.service");
describe('PenaltyService', function () {
    beforeEach(function () { return testing_1.TestBed.configureTestingModule({}); });
    it('should be created', function () {
        var service = testing_1.TestBed.get(penalty_service_1.PenaltyService);
        expect(service).toBeTruthy();
    });
});
//# sourceMappingURL=penalty.service.spec.js.map