import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Observer } from 'rxjs/src';
import { Country } from '../Model/Country';
import { Input } from '../Model/Input';
import { Output } from '../Model/Output';

@Injectable({
  providedIn: 'root'
})
export class PenaltyService {

    constructor(private http: HttpClient) { }
    getList(): Observable<Country[]> {
        return this.http.get<Country[]>('api/penalty');
    }
    GetPenalty(input: Input): Observable<Output> {
        return this.http.post<Output>('api/penalty', {
            startDate: input.startDate,
            endDate: input.endDate,
            country: input.country

        })

    }

}
