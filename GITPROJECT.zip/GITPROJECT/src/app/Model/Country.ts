﻿export class Country {
    CountryID: number
    CountryName:string
}