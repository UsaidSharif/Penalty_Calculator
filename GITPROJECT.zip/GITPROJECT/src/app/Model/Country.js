"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Country = void 0;
var Country = /** @class */ (function () {
    function Country() {
    }
    return Country;
}());
exports.Country = Country;
//# sourceMappingURL=Country.js.map