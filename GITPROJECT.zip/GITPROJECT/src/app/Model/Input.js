"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Input = void 0;
var Input = /** @class */ (function () {
    function Input() {
    }
    return Input;
}());
exports.Input = Input;
//# sourceMappingURL=Input.js.map