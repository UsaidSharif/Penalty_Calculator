﻿import { Country } from "./Country"

export class Input {
    startDate: Date
    endDate: Date
    country:Country
}