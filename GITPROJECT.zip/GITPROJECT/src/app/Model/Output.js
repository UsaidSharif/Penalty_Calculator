"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.Output = void 0;
var Output = /** @class */ (function () {
    function Output() {
    }
    return Output;
}());
exports.Output = Output;
//# sourceMappingURL=Output.js.map