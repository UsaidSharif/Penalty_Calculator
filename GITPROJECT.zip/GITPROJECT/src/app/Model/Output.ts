﻿export class Output {
    penalty: number
    countryCurrency:string
}