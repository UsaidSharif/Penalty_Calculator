﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Angular_PenaltyCalculator.Models
{
    public class HolidayClass
    {
        public string HolidayName { get; set; }
        public DateTime HolidayDate { get; set; }

    }
}
