﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Angular_PenaltyCalculator.Models
{
    public class Weekend
    {
        public string weekendDays { get; set; }
       
    }
    
}
