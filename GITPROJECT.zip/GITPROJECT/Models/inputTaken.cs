﻿
using Angular_PenaltyCalculator.DataLayer;
using Angular_PenaltyCalculator.Models;
using Project1.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace Project1.Models
{
    public class inputTaken
    {

            public DateTime startDate { get; set; }
            public DateTime endDate { get; set; }
            public CountryHolidays country { get; set; }
        
    }
}
