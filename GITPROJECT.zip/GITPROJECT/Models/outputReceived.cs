﻿using Angular_PenaltyCalculator.DataLayer;
using Angular_PenaltyCalculator.Models;
using Project1.Models;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;


namespace Project1.Models
{
    public class outputReceived 
    {
        public double penalty { get; set; }
        public string countryCurrency { get; set; }
        public outputReceived(double penalty, string currency)
        {
            this.penalty = penalty;
            this.countryCurrency = currency;
        }
    }
}
