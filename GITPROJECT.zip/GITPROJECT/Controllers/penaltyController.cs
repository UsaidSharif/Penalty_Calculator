﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Angular_PenaltyCalculator.DataLayer;
using Angular_PenaltyCalculator.Models;
using FinalWeb.BusinessLayer;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Project1.Models;

namespace Angular_PenaltyCalculator.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class penaltyController : ControllerBase
    {
        public readonly IConfiguration  configuration;
        public readonly ISQLDataHelper sQLData;
        public readonly IPenaltyCalculator penalty;
        public penaltyController(IConfiguration configuration,ISQLDataHelper sQLData,IPenaltyCalculator penaltyCalculator)
        {
            this.configuration = configuration;
            this.sQLData = sQLData;
            this.penalty = penaltyCalculator;
        }

        // GET: api/penalty
        [HttpGet]
        public List<CountryHolidays> Get()
        {
            
            List<CountryHolidays> countryList = sQLData.GetCountries();
            return countryList;
        }

        // POST: api/penalty
        [HttpPost]
        public outputReceived Post([FromBody] inputTaken input )
        {
            return penalty.ShowPenalty(input);
        }

        // PUT: api/penalty/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
