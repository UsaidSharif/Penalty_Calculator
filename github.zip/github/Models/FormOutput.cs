﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.Models
{
    public class FormOutput
    {
        public double penalty { get; set; }
        public string countryCurrency { get; set; }
        public FormOutput(double penalty,string currency)
        {
            this.penalty = penalty;
            this.countryCurrency = currency;
        }
    }
}
