﻿using FinalWeb.NewFolder1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.Models
{
    public class Countries : Country
    {
        public string countryCurrency { get; set; }
        public double countryExchange { get; set; }
        public double countryTax { get; set; }
        public List<Holiday> holidays { get; set; }
        public List<Weekend> weekends { get; set; }

        public Countries(int ID, string name, string currency, double exchange, double tax, List<Holiday> holiday, List<Weekend> weekends)
        {
            this.countryID = ID;
            this.countryName = name;
            this.countryCurrency = currency;
            this.countryExchange = exchange;
            this.countryTax = tax;
            this.holidays = holiday;
            this.weekends = weekends;
        }
    }
}
