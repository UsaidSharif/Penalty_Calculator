﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.Models
{
    public class Weekend
    {
        public DayOfWeek weekend { get; set; }

        public Weekend(string day)
        {
            this.weekend = (DayOfWeek)Enum.Parse(typeof(DayOfWeek), day);
        }
    }
}
