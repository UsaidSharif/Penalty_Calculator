﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.NewFolder1
{
    public class Country
    {
        public int countryID { get; set; }
        public string countryName { get; set; }

    }
}
