﻿using FinalWeb.NewFolder1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.Models
{
    public class FormInput
    {
        public DateTime startDate { get; set; }
        public DateTime endDate { get; set; }
        public Country country { get; set; }
    }
}

