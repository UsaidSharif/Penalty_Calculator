﻿using FinalWeb.DataLayer;
using FinalWeb.Models;
using FinalWeb.NewFolder1;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.BusinessLayer
{
    public class PenaltyCalculator:IPenaltyCalculator 
    {
        public readonly ISQLDataHelper _sQLDataHelper;
        public PenaltyCalculator(ISQLDataHelper sQLDataHelper)
        {
            this._sQLDataHelper = sQLDataHelper;
        }

        public List<Country> ShowCountries()
        {
            List<Country> countryList = _sQLDataHelper.GetCountries();
            return countryList;
        }

        public FormOutput ShowPenalty(FormInput input)
        {
            Countries countries = _sQLDataHelper.GetCountryInfo(input.country);
            double penalty = CalculatePenalty(countries,input);
            FormOutput output = new FormOutput(penalty, countries.countryCurrency);
            return output;
        }

        public double CalculatePenalty(Countries country,FormInput input)
        {
            int businessDays = GetBusinessDays(country,input);
            double penalty;
            if(businessDays>10)
            {
                penalty = (businessDays - 10) * (50 * country.countryExchange)*(1+(country.countryTax/100));
            }
            else
            {
                penalty = 0;
            }
            return penalty;
        }
       
        public int GetBusinessDays(Countries countries,FormInput input)
        {
            int days = 0;
            DateTime startDate = input.startDate;
            DateTime endDate =input.endDate;
            

            for (var date = startDate; date <= endDate; date = date.AddDays(1))
            {
                bool weekendCheck = false;
                bool holidayCheck = false;
                
                for (int i = 0; i < countries.weekends.Count; i++)
                {
                    if (date.DayOfWeek == (countries.weekends[i].weekend))
                    {
                        weekendCheck = true;
                    }
                }
                for (int i = 0; i < countries.holidays.Count; i++)
                {
                    if (date.DayOfYear == (countries.holidays[i].holidayDate).DayOfYear)
                    {
                        holidayCheck = true;
                    }
                }
                if (weekendCheck!=true && holidayCheck != true)
                {
                    days++;
                }


            }
            return days;
        }
       
    }
}
