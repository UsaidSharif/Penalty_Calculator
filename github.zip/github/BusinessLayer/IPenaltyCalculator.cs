﻿using FinalWeb.Models;
using FinalWeb.NewFolder1;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace FinalWeb.BusinessLayer
{
    public interface IPenaltyCalculator
    {
        public List<Country> ShowCountries();
        public FormOutput ShowPenalty(FormInput input);
    }
}
