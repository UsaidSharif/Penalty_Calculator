﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalWeb.BusinessLayer;
using FinalWeb.DataLayer;
using FinalWeb.Models;
using FinalWeb.NewFolder1;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FinalWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class PenaltyController : ControllerBase
    {
        
        public readonly IPenaltyCalculator penaltyCalculator;
        public PenaltyController(IPenaltyCalculator _penaltyCalculator)
        {
            this.penaltyCalculator = _penaltyCalculator;
        }

        [Route("GetCountry")]
        [HttpGet]
        public List<Country> Get()
        {
            
            List<Country> countryList = this.penaltyCalculator.ShowCountries();
            return countryList;
        }

        [Route("GetPenalty")]
        [HttpPost]
        public FormOutput Get([FromBody] FormInput input)
        {
            FormOutput output = this.penaltyCalculator.ShowPenalty(input);
            return output;
        }

       
    }
}
