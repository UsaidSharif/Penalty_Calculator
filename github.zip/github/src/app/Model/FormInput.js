"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FormInput = /** @class */ (function () {
    function FormInput() {
    }
    return FormInput;
}());
exports.FormInput = FormInput;
//# sourceMappingURL=FormInput.js.map