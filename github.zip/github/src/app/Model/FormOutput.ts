export class FormOutput {
    penalty: number
    currency: string
}
