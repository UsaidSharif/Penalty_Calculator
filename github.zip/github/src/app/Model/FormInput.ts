import { Country } from "./Country"

export class FormInput {
    startDate: Date
    endDate: Date
    country: Country
}
