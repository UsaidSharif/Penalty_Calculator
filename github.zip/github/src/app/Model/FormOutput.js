"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var FormOutput = /** @class */ (function () {
    function FormOutput() {
    }
    return FormOutput;
}());
exports.FormOutput = FormOutput;
//# sourceMappingURL=FormOutput.js.map