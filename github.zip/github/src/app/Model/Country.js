"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var Country = /** @class */ (function () {
    function Country() {
    }
    return Country;
}());
exports.Country = Country;
//# sourceMappingURL=Country.js.map