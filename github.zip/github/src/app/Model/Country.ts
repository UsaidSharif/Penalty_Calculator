export class Country
{
    countryID: number
    countryName: string

}
