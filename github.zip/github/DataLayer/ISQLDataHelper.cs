﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Configuration;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using FinalWeb.NewFolder1;
using FinalWeb.Models;

namespace FinalWeb.DataLayer
{
   public interface ISQLDataHelper
    {
        public string GetConnectionString(IConfiguration configuration);
        public List<Country> GetCountries();
        public List<Holiday> GetHolidays(int countryID);
        public List<Weekend> GetWeekends(int countryID);
        public Countries GetCountryInfo(Country country);

    }
}
