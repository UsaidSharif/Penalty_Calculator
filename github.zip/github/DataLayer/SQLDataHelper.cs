﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FinalWeb.NewFolder1;
using Microsoft.Extensions.Configuration;
using System.Data.SqlClient;
using FinalWeb.Models;

namespace FinalWeb.DataLayer
{
    public class SQLDataHelper : ISQLDataHelper
    {
        public readonly IConfiguration configuration;
        public SQLDataHelper(IConfiguration configuration)
        {
            this.configuration = configuration;

        }

        public string GetConnectionString(IConfiguration configuration)
        {
            var connectionString = configuration.GetConnectionString("MyConnectionString");
            return connectionString;

        }

        public List<Country> GetCountries()
        {

            SqlConnection cnn = new SqlConnection(GetConnectionString(configuration));
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            string sql = "Select * From CountryList";

            command = new SqlCommand(sql, cnn);
            dataReader = command.ExecuteReader();
            List<Country> countriesList = new List<Country>();
            while (dataReader.Read())
            {
                int ID = Convert.ToInt32(dataReader.GetValue(0));
                string name = dataReader.GetValue(1).ToString();

                Country country = new Country();
                country.countryID = ID;
                country.countryName = name;
                countriesList.Add(country);
            }
            dataReader.Close();
            command.Dispose();
            cnn.Close();
            return countriesList;
        }
        public Countries GetCountryInfo(Country country)
        {


            SqlConnection cnn = new SqlConnection(GetConnectionString(configuration));
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            string sql = "Select * From CountryData where countryID=@countryID";

            command = new SqlCommand(sql, cnn);
            command.Parameters.AddWithValue("@countryID", country.countryID);
            dataReader = command.ExecuteReader();

            Countries returnCountry=new Countries(0,"","",0,0,null,null);

            while (dataReader.Read())
            {

                string currency = dataReader.GetValue(1).ToString();
                double exchange = Convert.ToDouble(dataReader.GetValue(2));
                double tax = Convert.ToDouble(dataReader.GetValue(3));
                List<Holiday> holidayList = GetHolidays(country.countryID);
                List<Weekend> weekendList = GetWeekends(country.countryID);
                Countries selectedCountry = new Countries(country.countryID, country.countryName, currency, exchange, tax, holidayList,weekendList);
                returnCountry = selectedCountry;

            }
            return returnCountry;
        }
        public List<Holiday> GetHolidays(int countryID)
        {


            SqlConnection cnn = new SqlConnection(GetConnectionString(configuration));
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            string sql = "Select * From HolidayData where countryID=@countryID";
            command = new SqlCommand(sql, cnn);
            command.Parameters.AddWithValue("@countryID", countryID);
            dataReader = command.ExecuteReader();
            List<Holiday> holidayList = new List<Holiday>();
            while (dataReader.Read())
            {

                DateTime dateTime = Convert.ToDateTime(dataReader.GetValue(3));

                Holiday CountryHoliday = new Holiday();
                CountryHoliday.holidayDate = dateTime;
                holidayList.Add(CountryHoliday);
            }
            return holidayList;
        }
        public List<Weekend> GetWeekends(int countryID)
        {
            SqlConnection cnn = new SqlConnection(GetConnectionString(configuration));
            cnn.Open();
            SqlCommand command;
            SqlDataReader dataReader;
            string sql = "Select * From WeekendData where countryID=@countryID";
            command = new SqlCommand(sql, cnn);
            command.Parameters.AddWithValue("@countryID", countryID);
            dataReader = command.ExecuteReader();
            List<Weekend> weekendList = new List<Weekend>();
            while (dataReader.Read())
            {

                string dateTime = dataReader.GetValue(1).ToString();

                Weekend CountryWeekend = new Weekend(dateTime);
               
                weekendList.Add(CountryWeekend);
            }
            return weekendList;
        }

    }
}
